(function (Drupal, once) {
  'use strict';

  function cleanUrl() {
    return window.location.pathname + window.location.hash;
  }

  function hardReset() {
    window.location.assign(cleanUrl());
  }

  Drupal.behaviors.befHardResetFix = {
    attach: function (context) {

      // Hvis man allerede lander på ?reset=Nulstil, så ryd den straks.
      once('bef-hard-reset-strip-existing', 'body', context).forEach(function () {
        var params = new URLSearchParams(window.location.search);
        if (params.has('reset')) {
          hardReset();
        }
      });

      // Kapr KUN reset-knappen (name="reset").
      once('bef-hard-reset-click', 'input[type="submit"][name="reset"]', context)
        .forEach(function (btn) {
          btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            hardReset();
          }, true);
        });

      // Fallback: hvis formen submitter med reset alligevel.
      once('bef-hard-reset-submit', 'form.views-exposed-form', context)
        .forEach(function (form) {
          form.addEventListener('submit', function (e) {
            var submitter = e.submitter;
            if (submitter && submitter.name === 'reset') {
              e.preventDefault();
              e.stopPropagation();
              hardReset();
            }
          }, true);
        });
    }
  };

  Drupal.behaviors.convertLiToDivAndCleanFormClass = {
    attach: function (context) {

      // Fjern kun klassen search-full-text fra exposed form
      once('remove-search-full-text-class', 'form.views-exposed-form.search-full-text', context).forEach(function (form) {
        form.classList.remove('search-full-text');
      });

    }
  };

})(Drupal, once);
